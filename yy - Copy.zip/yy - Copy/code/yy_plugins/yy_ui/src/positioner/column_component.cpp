#include "column_component.h"

NS_YY_BEGIN
void ColumnComponent::OnCreate(const VariantMap& args)
{

}

void ColumnComponent::OnDestroyed()
{

}

NS_YY_END