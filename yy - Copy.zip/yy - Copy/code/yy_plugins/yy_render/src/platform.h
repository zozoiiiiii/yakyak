/************************************************************************/
/* 
@author:  junliang
@brief:   opengl es interface
@time:    2017/10/21
*/
/************************************************************************/
#pragma once


#define GL_GLEXT_PROTOTYPES
#include <GLES2/gl2.h>
#include <EGL/egl.h>